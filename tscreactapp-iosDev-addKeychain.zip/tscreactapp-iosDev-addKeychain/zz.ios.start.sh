npx react-native run-ios
