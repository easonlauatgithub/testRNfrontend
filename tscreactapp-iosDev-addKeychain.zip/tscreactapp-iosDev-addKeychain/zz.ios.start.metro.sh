npx react-native start
