npm install @react-navigation/native @react-navigation/native-stack
npm install react-native-screens react-native-safe-area-context