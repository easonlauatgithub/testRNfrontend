npx react-native start
# if something added to babel.config.js, use below to refresh
# npx react-native start --reset-cache