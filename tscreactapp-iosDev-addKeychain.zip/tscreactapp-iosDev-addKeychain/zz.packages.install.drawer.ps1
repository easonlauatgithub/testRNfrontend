npm install @react-navigation/drawer
npm install react-native-gesture-handler react-native-reanimated